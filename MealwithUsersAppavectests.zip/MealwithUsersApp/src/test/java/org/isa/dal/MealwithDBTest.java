package org.isa.dal;

import junit.framework.TestCase;
import org.junit.Assert;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MealwithDBTest extends TestCase {

    public void testGetConn() throws SQLException {

        MealwithDB test = new MealwithDB();

        Statement stm = test.getConn().createStatement();

        ResultSet testresult = stm.executeQuery("SELECT * FROM users");

        test.conn.close();

        Assert.assertNotNull(test.getConn());
        Assert.assertNotNull(testresult);

    }
}