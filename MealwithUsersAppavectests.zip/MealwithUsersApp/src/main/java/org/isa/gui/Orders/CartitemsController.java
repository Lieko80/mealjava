package org.isa.gui.Orders;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import org.isa.dal.CartItems;
import org.isa.dal.CartItemsDAO;
import org.isa.dal.Commande;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class CartitemsController implements Initializable {
    public TableView<CartItems> cartdetail;
    public TableColumn<CartItems, Integer> col_id;
    public TableColumn<CartItems, String> col_name;
    public TableColumn<CartItems, Integer> col_quantity;
    public TableColumn<CartItems, Float> col_price;
    public int cartId;
    public TextField datafromorders;
    public AnchorPane cartPane;

    ObservableList<CartItems> model = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle rb) {
        //initialisation pour remplir le tableview depuis la bdd
        CartItemsDAO repo = null;
        try {
            repo = new CartItemsDAO();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        assert repo != null;
//        model.addAll(repo.ListAll()); essai 16/12 18h

        model.addAll(repo.ListByCart(Integer.parseInt(datafromorders.getText())));
        cartdetail.setEditable(false);

        // Jonction du tableau avec les données
        col_id.setCellValueFactory(new PropertyValueFactory<>("ingredientId"));
        col_quantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        col_price.setCellValueFactory(new PropertyValueFactory<>("price"));

        cartdetail.setItems(model);
    }
    @FXML
    private void receiveData(MouseEvent event) {
        //essai Isa :

        Node node = (Node) event.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        Commande cde = (Commande) stage.getUserData();
        int cartId = cde.getCartId();
        datafromorders.setText(String.valueOf(cartId));
        /* Fabien 16/12 17h :
        // Step 1
        Node node = (Node) event.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        // Step 2
        OrdersController u = (OrdersController) stage.getUserData();
        // Step 3
        receiveData = u.txt_idcart;
        System.out.println("receivedata = " + u.txt_idcart);

         */
    }


}
