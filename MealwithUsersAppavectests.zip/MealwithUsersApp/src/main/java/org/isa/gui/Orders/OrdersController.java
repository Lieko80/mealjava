package org.isa.gui.Orders;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import org.isa.dal.Commande;
import org.isa.dal.CommandeDAO;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class OrdersController implements Initializable {
    public TableView<Commande> table_list;
    public TableColumn<Commande, String> col_orders_number;
    public TableColumn<Commande, String> col_email;
    public TableColumn<Commande, String> col_firstname;
    public TableColumn<Commande, String> col_lastname;
    public TextField txt_search;
    public AnchorPane pane_details;
    public TextField txt_email;
    public TextField txt_firstname;
    public TextField txt_lastname;
    public TextField txt_address;
    public TextField txt_order;
    public TextField txt_delivery;
    public Button btn_order_detail;
    public TextField txt_idcart;
    public AnchorPane cart_detail;
    public TableView cartdetail;
    public TableColumn col_id;
    public TableColumn col_name;
    public TableColumn col_quantity;
    public TableColumn col_price;

    ObservableList<Commande> model = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle rb) {
        //initialisation pour remplir le tableview depuis la bdd
        CommandeDAO repo = null;
        try {
            repo = new CommandeDAO();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        assert repo != null;
        model.addAll(repo.ListAll());
        table_list.setEditable(false);

        // Jonction du tableau avec les données
        col_orders_number.setCellValueFactory(new PropertyValueFactory<>("id"));
        col_email.setCellValueFactory(new PropertyValueFactory<>("email"));
        col_firstname.setCellValueFactory(new PropertyValueFactory<>("firstname"));
        col_lastname.setCellValueFactory(new PropertyValueFactory<>("lastname"));

        // 1. Wrap the ObservableList in a FilteredList (initially display all data).
        FilteredList<Commande> filteredData = new FilteredList<>(model, p -> true);

        // 2. Set the filter Predicate whenever the filter changes.
        txt_search.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(person -> {
                // If filter text is empty, display all users.
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Compare email of every user with filter text.
                String lowerCaseFilter = newValue.toLowerCase();

                if (person.getEmail().toLowerCase().contains(lowerCaseFilter)) {
                    return true; // Filter matches email
                }
                return false; // Does not match.
            });
        });

        // 3. Wrap the FilteredList in a SortedList.
        SortedList<Commande> sortedData = new SortedList<>(filteredData);

        // 4. Bind the SortedList comparator to the TableView comparator.
        sortedData.comparatorProperty().bind(table_list.comparatorProperty());

        // 5. Add sorted (and filtered) data to the table.
        table_list.setItems(sortedData);
    }

    public void ShowPanel(MouseEvent mouseEvent) {
        //récupérer utilisateur sélectionné :
        Commande c = (Commande) table_list.getSelectionModel().getSelectedItem();
        //afficher message erreur si rien de sélectionné dans le tableau :
        details(c);
    }

    public void details(Commande person) {
        try {
            //affiche la fenetre detail quand on click sur la liste
            if (table_list.isFocused()) {
                btn_order_detail.setVisible(true);
            }

            if (person != null) {
                // Fill the labels with info from the User object given as parameter:
                txt_email.setText(person.getEmail());
                txt_firstname.setText(person.getFirstname());
                txt_lastname.setText(person.getLastname());
                txt_address.setText(person.getDeliveryAddress());
                txt_order.setText(String.valueOf(person.getOrderDate()));
                txt_delivery.setText(String.valueOf(person.getDeliveryDate()));
                txt_idcart.setText(String.valueOf(person.getCartId()));
            } else {
                // Person is null, so remove all the text:
                txt_email.setText("");
                txt_firstname.setText("");
                txt_lastname.setText("");
                txt_address.setText("");
                txt_order.setText("");
                txt_delivery.setText("");
                txt_idcart.setText("");

            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @FXML
    private void ShowCart(ActionEvent event) throws IOException {

        Commande cde = new Commande();

        Node node = (Node) event.getSource();
        Stage newStage = new Stage();

        newStage = (Stage) node.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/org/isa/gui/Orders/cartitems.fxml"));
        newStage.setUserData(cde);
        Scene scene = new Scene(root);
        newStage.setScene(scene);
        newStage.show();

    /* fabien 16/12 17h :
        OrdersController u = new OrdersController();
        Node node = (Node) event.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        Stage newStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("/org/isa/gui/Orders/cartitems.fxml"));
        stage.setUserData(u);
        Scene scene = new Scene(root);
        newStage.setScene(scene);
        newStage.show();    */
    }

}

